import byuiMagnifier from "zx-magnifie";

export default byuiMagnifier;
