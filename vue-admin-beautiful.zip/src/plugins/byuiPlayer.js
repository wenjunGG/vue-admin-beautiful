import { custom, flv, hls, mp4 } from "zx-player";

const byuiPlayerMp4 = mp4;
const byuiPlayerHls = hls;
const byuiPlayerFlv = flv;
const byuiPlayerCustom = custom;
export { byuiPlayerMp4, byuiPlayerHls, byuiPlayerFlv, byuiPlayerCustom };
